﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Text.RegularExpressions;


namespace ProjectFinal
{
    public partial class Form1 : Form
    {
        SerialPort port;
        public Form1()
        {
            InitializeComponent();
            port = new SerialPort("COM3", 9600);
            port.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*for (int i = 1; i <= 100; i++)
           {
               Thread.Sleep(9000);
               textBox1.Text += "Rahul";

           }*/
            /*for (int i = 1; i<= 100; i++) {
                string abc = "Hello\nThere\nFriend";
                textBox1.Text += abc;
            }*/
            /*while (true) {
                string abc = "Hello\nThere\nFriend";
                textBox1.Text += abc;
                
            }*/



            string distance = port.ReadExisting();


            // Split on one or more non-digit characters.
            string[] numbers = Regex.Split(distance, @"\D+");
            foreach (string value in numbers)
            {
                if (!string.IsNullOrEmpty(value))
                {
                    int i = int.Parse(value);

                   label3.Text = i + "";
                }
            }


            bool result = Regex.IsMatch(distance, "\\bHigh\\b");
            if (result)
            {
                pictureBox1.Image = Properties.Resources.fire1;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else {
                pictureBox1.Image = Properties.Resources.nofire;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }



        }
    }
}
